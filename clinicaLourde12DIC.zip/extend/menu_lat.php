
<nav class="blue darken-2">
    <a href="" data-activates="menu" class="button-collapse"><i class="material-icons">menu</i></a>  
</nav>

<ul id="menu" class="side-nav fixed">
    <li>
        <div class="userView">
            <div class="background">
                <img src="../img/bg.jpg" alt="">
            </div>
            <a href="#!" class="circle"><img class="responsive-img" src="../img/loro.jpg" alt=""></a>
            <a href="#!" class="white-text">Hugo N Romante</a>
            <a href="#!" class="white-text">hugonromante@gmail.com</a>
        </div>
    </li>
    <li><a href="../menu/"><i class="material-icons">home</i>Menu</a></li>
    <li><div class="divider"></div></li>
    <li><a href="../reservas/"><i class="material-icons">add</i>Generar reserva</a></li>
    <li><div class="divider"></div></li>    
    <li><a href="../reservas/listadoRes.php"><i class="material-icons">format_list_bulleted</i>Mis reservas</a></li>
    <li><div class="divider"></div></li>  
    <li><a href="../especialidades/"><i class="material-icons">format_list_bulleted</i>Nuestras especialidades</a></li>
    <li><div class="divider"></div></li>  
</ul>
