<?php //include '../conexion/conexion.php'; DESHABILITAMOS LA CONEXION DEL HEADER PARA QUE NO REDECLARE LA CLASE PRODUCTO?> 
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Practica PHP</title>
    <script type="text/javascript" src="../js/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.1/sweetalert2.all.min.js"></script>
    

    <script type="text/javascript" src="../js/base.js"></script>
</head>

<body>
 
<main>
    <link rel="stylesheet" href="../css/header.css"> 
    
    <nav class="blue darken-1">
        <a href="" data-activates="menu" class="button-collapse"><i class="material-icons">menu</i></a>  
    </nav>