$( document ).ready(function(){

    // Inicializar navbarssdsdsd
    $(".button-collapse").sideNav();
});